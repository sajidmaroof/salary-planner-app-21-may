import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

final appAuthNotifier = AppAuthNotifier();

class AppAuthNotifier extends ChangeNotifier {
  User? _user;
  bool _isLoading = true;
  bool _setupComplete = false;

  AppAuthNotifier() {
    // Safety net: never stay in loading state longer than 8 seconds.
    Future.delayed(const Duration(seconds: 8), () {
      if (_isLoading) {
        _isLoading = false;
        notifyListeners();
      }
    });
    FirebaseAuth.instance.authStateChanges().listen(_onAuthChanged);
  }

  Future<void> _onAuthChanged(User? user) async {
    _user = user;
    if (user != null) {
      await _fetchSetupStatus(user.uid);
    } else {
      _setupComplete = false;
    }
    _isLoading = false;
    notifyListeners();
  }

  Future<void> _fetchSetupStatus(String uid) async {
    try {
      final doc = await FirebaseFirestore.instance
          .collection('users')
          .doc(uid)
          .get()
          .timeout(const Duration(seconds: 5));
      _setupComplete = doc.data()?['setupComplete'] as bool? ?? false;
    } catch (_) {
      _setupComplete = false;
    }
  }

  Future<void> reloadUserData() async {
    if (_user != null) {
      await _fetchSetupStatus(_user!.uid);
      notifyListeners();
    }
  }

  void markSetupComplete() {
    _setupComplete = true;
    notifyListeners();
  }

  void markSetupIncomplete() {
    _setupComplete = false;
    notifyListeners();
  }

  Future<void> signOut() async {
    await FirebaseAuth.instance.signOut();
  }

  User? get user => _user;
  bool get isLoading => _isLoading;
  bool get setupComplete => _setupComplete;
}
