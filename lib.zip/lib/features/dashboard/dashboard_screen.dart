import 'dart:convert';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';
import '../../core/constants/app_colors.dart';
import '../../data/models/expense.dart';
import '../../data/models/user_settings.dart';
import '../../providers/app_providers.dart';
import '../../services/firestore_service.dart';
import 'widgets/daily_budget_card.dart';

// All categories stored and displayed in lowercase to avoid mismatch
const _kCategories = [
  'food', 'transport', 'shopping', 'entertainment',
  'health', 'bills', 'education', 'other'
];

class DashboardScreen extends ConsumerStatefulWidget {
  const DashboardScreen({Key? key}) : super(key: key);
  @override
  ConsumerState<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends ConsumerState<DashboardScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _syncIfNeeded());
  }

  Future<void> _syncIfNeeded() async {
    if (ref.read(userSettingsProvider) != null) return;
    try {
      final data = await FirestoreService.getUserData();
      if (data == null || !mounted) return;
      final settings = UserSettings(
        monthlyIncome: (data['monthlyIncome'] as num).toDouble(),
        nextSalaryDate: (data['nextSalaryDate'] as Timestamp).toDate(),
        fixedExpenses: (data['fixedExpenses'] as num).toDouble(),
        savingsGoal: (data['savingsGoal'] as num).toDouble(),
        currencyCode: data['currencyCode'] as String? ?? 'PKR',
        expensesBreakdown: data['expensesBreakdown'] as String?,
      );
      final box = ref.read(userSettingsBoxProvider);
      await box.put('settings', settings);
      if (mounted) {
        ref.read(userSettingsProvider.notifier).state = settings;
        ref.read(currencyCodeProvider.notifier).state = settings.currencyCode;
      }
    } catch (_) {}
  }

  // ── Delete expense ────────────────────────────────────────────────────────
  Future<void> _deleteExpense(Expense expense) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: const Text('Delete Expense?', style: TextStyle(fontWeight: FontWeight.w800)),
        content: const Text('Are you sure you want to delete this expense?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          ElevatedButton(
            onPressed: () => Navigator.pop(ctx, true),
            style: ElevatedButton.styleFrom(backgroundColor: AppColors.danger, elevation: 0, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
            child: const Text('Delete', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
    if (confirmed != true) return;

    // Delete from Hive
    await expense.delete();

    // Delete from Firestore
    try {
      final uid = FirebaseAuth.instance.currentUser?.uid;
      if (uid != null) {
        final snapshot = await FirebaseFirestore.instance
            .collection('users').doc(uid).collection('expenses')
            .where('amount', isEqualTo: expense.amount)
            .where('category', isEqualTo: expense.category)
            .limit(1).get();
        for (final doc in snapshot.docs) { await doc.reference.delete(); }
      }
    } catch (_) {}

    ref.invalidate(expensesProvider);
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Expense deleted'), backgroundColor: AppColors.danger, duration: Duration(seconds: 2)),
      );
    }
  }

  // ── Edit expense ──────────────────────────────────────────────────────────
  void _editExpense(Expense expense) {
    final amountCtrl = TextEditingController(text: expense.amount.toStringAsFixed(0));
    final noteCtrl = TextEditingController(text: expense.note ?? '');

    // Normalize category to lowercase and ensure it exists in list
    final rawCat = expense.category.toLowerCase().trim();
    String selectedCategory = _kCategories.contains(rawCat) ? rawCat : 'other';

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setBS) => Padding(
          padding: EdgeInsets.only(bottom: MediaQuery.of(ctx).viewInsets.bottom),
          child: Container(
            padding: const EdgeInsets.fromLTRB(24, 16, 24, 32),
            decoration: const BoxDecoration(
              color: AppColors.surface,
              borderRadius: BorderRadius.vertical(top: Radius.circular(32)),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Center(child: Container(width: 40, height: 4, decoration: BoxDecoration(color: AppColors.border, borderRadius: BorderRadius.circular(2)))),
                const SizedBox(height: 20),
                const Text('Edit Expense', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: AppColors.textPrimary)),
                const SizedBox(height: 20),
                // Amount
                TextField(
                  controller: amountCtrl,
                  keyboardType: const TextInputType.numberWithOptions(decimal: true),
                  decoration: _inputDeco('Amount', Icons.payments_rounded),
                ),
                const SizedBox(height: 16),
                // Category dropdown — all lowercase, no duplicates
                DropdownButtonFormField<String>(
                  value: selectedCategory,
                  decoration: _inputDeco('Category', Icons.category_rounded),
                  items: _kCategories.map((c) => DropdownMenuItem(
                    value: c,
                    child: Text(c[0].toUpperCase() + c.substring(1)),
                  )).toList(),
                  onChanged: (val) { if (val != null) setBS(() => selectedCategory = val); },
                ),
                const SizedBox(height: 16),
                // Note
                TextField(
                  controller: noteCtrl,
                  decoration: _inputDeco('Note (optional)', Icons.note_rounded),
                ),
                const SizedBox(height: 24),
                // Save button
                SizedBox(
                  width: double.infinity,
                  height: 54,
                  child: ElevatedButton(
                    onPressed: () async {
                      final newAmount = double.tryParse(amountCtrl.text.trim());
                      if (newAmount == null || newAmount <= 0) return;

                      // Update Hive
                      expense.amount = newAmount;
                      expense.category = selectedCategory;
                      expense.note = noteCtrl.text.trim().isEmpty ? null : noteCtrl.text.trim();
                      await expense.save();

                      // Update Firestore
                      try {
                        final uid = FirebaseAuth.instance.currentUser?.uid;
                        if (uid != null) {
                          final snapshot = await FirebaseFirestore.instance
                              .collection('users').doc(uid).collection('expenses')
                              .orderBy('date', descending: true).limit(50).get();
                          for (final doc in snapshot.docs) {
                            final data = doc.data();
                            if ((data['category'] as String? ?? '').toLowerCase() == selectedCategory.toLowerCase()) {
                              await doc.reference.update({
                                'amount': newAmount,
                                'category': selectedCategory,
                                'note': expense.note ?? '',
                              });
                              break;
                            }
                          }
                        }
                      } catch (_) {}

                      ref.invalidate(expensesProvider);
                      if (ctx.mounted) Navigator.pop(ctx);
                      if (mounted) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text('Expense updated!'), backgroundColor: AppColors.success, duration: Duration(seconds: 2)),
                        );
                      }
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColors.primary, elevation: 0,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
                    ),
                    child: const Text('Save Changes', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 16)),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  InputDecoration _inputDeco(String label, IconData icon) => InputDecoration(
    labelText: label,
    prefixIcon: Icon(icon),
    filled: true,
    fillColor: AppColors.background,
    border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: const BorderSide(color: AppColors.border)),
    enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: const BorderSide(color: AppColors.border)),
    focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: const BorderSide(color: AppColors.primary, width: 2)),
  );

  @override
  Widget build(BuildContext context) {
    final stats = ref.watch(dailyStatsProvider);
    final settings = ref.watch(userSettingsProvider);
    final todaysExpenses = ref.watch(todaysExpensesProvider);
    final format = ref.watch(formatCurrencyProvider);

    if (stats == null) {
      return const Scaffold(
        backgroundColor: AppColors.background,
        body: Center(child: CircularProgressIndicator(valueColor: AlwaysStoppedAnimation(AppColors.primary))),
      );
    }

    final displayName = FirebaseAuth.instance.currentUser?.displayName ?? '';

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text('DASHBOARD'),
            if (displayName.isNotEmpty)
              Text('Hello, $displayName!', style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w500, color: AppColors.textSecondary)),
          ],
        ),
        actions: [
          IconButton(icon: const Icon(Icons.calendar_month_rounded), onPressed: () => context.push('/history')),
          IconButton(icon: const Icon(Icons.settings_rounded), onPressed: () => context.push('/settings')),
        ],
      ),
      body: Stack(
        children: [
          Positioned(
            top: -100, right: -50,
            child: Container(
              width: 300, height: 300,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(colors: [AppColors.primary.withOpacity(0.15), Colors.transparent]),
              ),
            ),
          ),
          SingleChildScrollView(
            padding: const EdgeInsets.all(20.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                // Days until payday
                Center(
                  child: GestureDetector(
                    onTap: () => _showPaydayDetailsSheet(stats, format),
                    child: Container(
                      padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 24),
                      decoration: BoxDecoration(color: AppColors.surfaceLight, borderRadius: BorderRadius.circular(30), border: Border.all(color: AppColors.border)),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const Icon(Icons.calendar_month_rounded, size: 16, color: AppColors.primary),
                          const SizedBox(width: 8),
                          Text('${stats.daysLeft} DAYS UNTIL PAYDAY', style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w800, color: AppColors.textPrimary, letterSpacing: 1)),
                          const SizedBox(width: 6),
                          const Icon(Icons.chevron_right_rounded, size: 14, color: AppColors.primary),
                        ],
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 32),

                // Summary Cards
                GridView.count(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  crossAxisCount: 2, crossAxisSpacing: 16, mainAxisSpacing: 16, childAspectRatio: 1.4,
                  children: [
                    _SummaryCard(label: 'MONTHLY INCOME', formattedValue: format(stats.monthlyIncome), icon: Icons.account_balance_wallet_rounded, color: const Color(0xFF64748B), iconTint: const Color(0xFF64748B), onTap: () => _showIncomeDialog(stats.monthlyIncome, format)),
                    _SummaryCard(label: 'FIXED EXPENSES', formattedValue: format(stats.fixedExpenses), icon: Icons.receipt_long_rounded, color: const Color(0xFF3B82F6), iconTint: const Color(0xFF3B82F6), onTap: () => _showFixedExpensesSheet(context, settings?.expensesBreakdown, format)),
                    _SummaryCard(label: 'SAVINGS GOAL', formattedValue: format(stats.savingsGoal), icon: Icons.savings_rounded, color: const Color(0xFF8B5CF6), iconTint: const Color(0xFF8B5CF6), onTap: () => _showSavingsGoalSheet(stats, format)),
                    _SummaryCard(label: 'REMAINING', formattedValue: format(stats.remainingBalance), icon: Icons.account_balance_rounded, isHighlighted: true, color: _getRemainingBalanceColor(stats.remainingBalance, stats.availableSpending), iconTint: const Color(0xFF10B981), onTap: () => _showSpendingBreakdownSheet(format)),
                  ],
                ),
                const SizedBox(height: 24),

                // Safe to Spend Card
                GestureDetector(
                  onTap: () => _showDailyBudgetSheet(stats, format),
                  child: DailyBudgetCard(dailyLimit: stats.dailyLimit, spentToday: stats.spentToday, remainingToday: stats.remainingToday),
                ),
                const SizedBox(height: 40),

                // Today's Expenses
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text("Today's Expenses", style: Theme.of(context).textTheme.titleLarge),
                    TextButton(
                      onPressed: () => context.push('/history'),
                      child: Text('View All', style: TextStyle(color: AppColors.primary.withOpacity(0.8), fontWeight: FontWeight.w700)),
                    ),
                  ],
                ),

                if (todaysExpenses.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 12),
                    child: Row(
                      children: [
                        Icon(Icons.swipe_left_rounded, size: 16, color: AppColors.textSecondary.withOpacity(0.6)),
                        const SizedBox(width: 4),
                        Text('Swipe left to edit or delete', style: TextStyle(fontSize: 12, color: AppColors.textSecondary.withOpacity(0.6))),
                      ],
                    ),
                  ),

                if (todaysExpenses.isEmpty)
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 40),
                    child: Center(
                      child: Column(
                        children: [
                          Icon(Icons.receipt_long_outlined, size: 54, color: AppColors.textSecondary.withOpacity(0.3)),
                          const SizedBox(height: 16),
                          Text('No expenses today!', style: TextStyle(color: AppColors.textSecondary, fontWeight: FontWeight.w600)),
                        ],
                      ),
                    ),
                  )
                else
                  ...todaysExpenses.take(5).map((expense) => _SwipeableExpenseItem(
                    key: ValueKey(expense.key),
                    expense: expense,
                    format: format,
                    onEdit: () => _editExpense(expense),
                    onDelete: () => _deleteExpense(expense),
                  )),

                const SizedBox(height: 100),
              ],
            ),
          ),
        ],
      ),
      floatingActionButton: Container(
        height: 64,
        margin: const EdgeInsets.symmetric(horizontal: 20),
        decoration: BoxDecoration(
          gradient: const LinearGradient(colors: [Color(0xFF818CF8), Color(0xFF22D3EE)], begin: Alignment.topLeft, end: Alignment.bottomRight),
          borderRadius: BorderRadius.circular(32),
          boxShadow: [BoxShadow(color: const Color(0xFF818CF8).withOpacity(0.4), blurRadius: 20, offset: const Offset(0, 10))],
        ),
        child: FloatingActionButton.extended(
          onPressed: () => context.push('/add-expense'),
          backgroundColor: Colors.transparent, elevation: 0, highlightElevation: 0, foregroundColor: Colors.white,
          icon: const Icon(Icons.add_rounded, size: 28),
          label: const Text('ADD EXPENSE', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.5)),
        ),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
    );
  }

  // ── 1. Monthly Income dialog ──────────────────────────────────────────────
  void _showIncomeDialog(double current, String Function(double) format) {
    final ctrl = TextEditingController(text: current.toStringAsFixed(0));
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        title: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(color: const Color(0xFF64748B).withOpacity(0.1), borderRadius: BorderRadius.circular(12)),
              child: const Icon(Icons.account_balance_wallet_rounded, color: Color(0xFF64748B), size: 20),
            ),
            const SizedBox(width: 12),
            const Text('Monthly Income', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
          ],
        ),
        content: TextField(
          controller: ctrl,
          autofocus: true,
          keyboardType: TextInputType.number,
          decoration: InputDecoration(
            labelText: 'Income amount',
            prefixIcon: const Icon(Icons.payments_rounded),
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: AppColors.primary, elevation: 0, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
            onPressed: () {
              final val = double.tryParse(ctrl.text.trim());
              if (val == null || val <= 0) return;
              final s = ref.read(userSettingsProvider);
              if (s == null) return;
              s.monthlyIncome = val;
              s.save();
              ref.read(userSettingsProvider.notifier).state = s;
              ref.invalidate(dailyStatsProvider);
              FirestoreService.saveUserSetup(
                monthlyIncome: val,
                nextSalaryDate: s.nextSalaryDate,
                fixedExpenses: s.fixedExpenses,
                savingsGoal: s.savingsGoal,
                currencyCode: s.currencyCode,
                expensesBreakdown: s.expensesBreakdown,
              ).catchError((_) {});
              Navigator.pop(ctx);
            },
            child: const Text('Save', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700)),
          ),
        ],
      ),
    );
  }

  // ── 2. Savings Goal sheet ──────────────────────────────────────────────────
  void _showSavingsGoalSheet(DailyStats stats, String Function(double) format) {
    final goalCtrl = TextEditingController(text: stats.savingsGoal.toStringAsFixed(0));
    // Savings secured = how much of the goal is protected (eaten into if overspent)
    final secured = (stats.savingsGoal + stats.remainingBalance).clamp(0.0, stats.savingsGoal);
    final pct = stats.savingsGoal > 0 ? secured / stats.savingsGoal : 1.0;
    final onTrack = stats.remainingBalance >= 0;

    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (sheetCtx) => StatefulBuilder(
        builder: (ctx, setSt) => Padding(
          padding: EdgeInsets.only(bottom: MediaQuery.of(ctx).viewInsets.bottom),
          child: Container(
            decoration: const BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.vertical(top: Radius.circular(32))),
            padding: const EdgeInsets.fromLTRB(24, 12, 24, 32),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Center(child: Container(width: 40, height: 4, decoration: BoxDecoration(color: AppColors.border, borderRadius: BorderRadius.circular(2)))),
                const SizedBox(height: 20),
                Row(
                  children: [
                    Container(padding: const EdgeInsets.all(10), decoration: BoxDecoration(color: const Color(0xFF8B5CF6).withOpacity(0.12), borderRadius: BorderRadius.circular(14)), child: const Icon(Icons.savings_rounded, color: Color(0xFF8B5CF6), size: 22)),
                    const SizedBox(width: 14),
                    const Expanded(child: Text('Savings Goal', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800))),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                      decoration: BoxDecoration(color: onTrack ? AppColors.success.withOpacity(0.12) : AppColors.danger.withOpacity(0.12), borderRadius: BorderRadius.circular(10)),
                      child: Row(
                        children: [
                          Icon(onTrack ? Icons.check_circle_rounded : Icons.warning_rounded, size: 14, color: onTrack ? AppColors.success : AppColors.danger),
                          const SizedBox(width: 4),
                          Text(onTrack ? 'ON TRACK' : 'AT RISK', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w800, color: onTrack ? AppColors.success : AppColors.danger)),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 28),

                // Goal amount row
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      const Text('Monthly Goal', style: TextStyle(fontSize: 12, color: AppColors.textSecondary, fontWeight: FontWeight.w600)),
                      const SizedBox(height: 4),
                      Text(format(stats.savingsGoal), style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w900, color: Color(0xFF8B5CF6))),
                    ]),
                    Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                      const Text('Currently Secured', style: TextStyle(fontSize: 12, color: AppColors.textSecondary, fontWeight: FontWeight.w600)),
                      const SizedBox(height: 4),
                      Text(format(secured), style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: onTrack ? AppColors.success : AppColors.danger)),
                    ]),
                  ],
                ),
                const SizedBox(height: 20),

                // Progress bar
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text('Progress', style: TextStyle(fontSize: 12, color: AppColors.textSecondary, fontWeight: FontWeight.w600)),
                    Text('${(pct * 100).toStringAsFixed(0)}%', style: TextStyle(fontSize: 13, fontWeight: FontWeight.w800, color: onTrack ? AppColors.success : AppColors.danger)),
                  ],
                ),
                const SizedBox(height: 8),
                ClipRRect(
                  borderRadius: BorderRadius.circular(8),
                  child: LinearProgressIndicator(
                    value: pct,
                    minHeight: 14,
                    backgroundColor: AppColors.border,
                    valueColor: AlwaysStoppedAnimation(onTrack ? AppColors.success : AppColors.danger),
                  ),
                ),
                const SizedBox(height: 20),

                // Info row
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(color: AppColors.surfaceLight, borderRadius: BorderRadius.circular(16), border: Border.all(color: AppColors.border)),
                  child: Row(
                    children: [
                      const Text('💡', style: TextStyle(fontSize: 18)),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Text(
                          onTrack
                              ? 'Great! Your savings goal of ${format(stats.savingsGoal)} is fully protected this month.'
                              : 'You\'ve overspent by ${format(-stats.remainingBalance)}. ${format(-stats.remainingBalance < stats.savingsGoal ? stats.savingsGoal - (-stats.remainingBalance) : 0)} of your savings is still secured.',
                          style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w500, color: AppColors.textPrimary),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 24),

                // Edit goal
                const Text('EDIT GOAL', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w800, color: AppColors.textSecondary, letterSpacing: 1.2)),
                const SizedBox(height: 8),
                Row(
                  children: [
                    Expanded(
                      child: TextField(
                        controller: goalCtrl,
                        keyboardType: TextInputType.number,
                        decoration: InputDecoration(
                          labelText: 'New savings goal',
                          prefixIcon: const Icon(Icons.savings_rounded),
                          border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
                          contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF8B5CF6), elevation: 0,
                        minimumSize: Size.zero, tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                      ),
                      onPressed: () {
                        final val = double.tryParse(goalCtrl.text.trim());
                        if (val == null || val < 0) return;
                        final s = ref.read(userSettingsProvider);
                        if (s == null) return;
                        s.savingsGoal = val;
                        s.save();
                        ref.read(userSettingsProvider.notifier).state = s;
                        ref.invalidate(dailyStatsProvider);
                        FirestoreService.saveUserSetup(
                          monthlyIncome: s.monthlyIncome,
                          nextSalaryDate: s.nextSalaryDate,
                          fixedExpenses: s.fixedExpenses,
                          savingsGoal: val,
                          currencyCode: s.currencyCode,
                          expensesBreakdown: s.expensesBreakdown,
                        ).catchError((_) {});
                        Navigator.pop(ctx);
                      },
                      child: const Text('Save', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700)),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ── 3. Spending Breakdown sheet (Remaining card) ───────────────────────────
  void _showSpendingBreakdownSheet(String Function(double) format) {
    final allExpenses = ref.read(expensesProvider);
    final totalSpent = allExpenses.fold(0.0, (s, e) => s + e.amount);
    final Map<String, double> byCategory = {};
    for (final e in allExpenses) {
      final key = e.category.isNotEmpty ? (e.category[0].toUpperCase() + e.category.substring(1).toLowerCase()) : 'Other';
      byCategory[key] = (byCategory[key] ?? 0) + e.amount;
    }
    final sorted = byCategory.entries.toList()..sort((a, b) => b.value.compareTo(a.value));
    const categoryColors = [
      Color(0xFF7B2FF7), Color(0xFF3B82F6), Color(0xFF10B981),
      Color(0xFFF59E0B), Color(0xFFEF4444), Color(0xFF8B5CF6),
      Color(0xFF06B6D4), Color(0xFFEC4899),
    ];

    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (ctx) => Container(
        decoration: const BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.vertical(top: Radius.circular(32))),
        padding: const EdgeInsets.fromLTRB(24, 12, 24, 32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(child: Container(width: 40, height: 4, decoration: BoxDecoration(color: AppColors.border, borderRadius: BorderRadius.circular(2)))),
            const SizedBox(height: 20),
            Row(
              children: [
                Container(padding: const EdgeInsets.all(10), decoration: BoxDecoration(color: AppColors.success.withOpacity(0.12), borderRadius: BorderRadius.circular(14)), child: const Icon(Icons.pie_chart_rounded, color: AppColors.success, size: 22)),
                const SizedBox(width: 14),
                const Expanded(child: Text('Spending Breakdown', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800))),
              ],
            ),
            const SizedBox(height: 20),

            // Total spent banner
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
              decoration: BoxDecoration(gradient: AppColors.primaryGradient, borderRadius: BorderRadius.circular(16)),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text('Total Spent', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600, fontSize: 14)),
                  Text(format(totalSpent), style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 22)),
                ],
              ),
            ),
            const SizedBox(height: 20),

            if (sorted.isEmpty)
              const Padding(
                padding: EdgeInsets.symmetric(vertical: 24),
                child: Center(child: Text('No expenses recorded yet.', style: TextStyle(color: AppColors.textSecondary, fontWeight: FontWeight.w500))),
              )
            else
              ConstrainedBox(
                constraints: BoxConstraints(maxHeight: MediaQuery.of(ctx).size.height * 0.45),
                child: ListView.separated(
                  shrinkWrap: true,
                  itemCount: sorted.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 12),
                  itemBuilder: (_, i) {
                    final entry = sorted[i];
                    final pct = totalSpent > 0 ? entry.value / totalSpent : 0.0;
                    final color = categoryColors[i % categoryColors.length];
                    return Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Container(width: 12, height: 12, decoration: BoxDecoration(color: color, shape: BoxShape.circle)),
                            const SizedBox(width: 10),
                            Expanded(child: Text(entry.key, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14))),
                            Text(format(entry.value), style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 14)),
                            const SizedBox(width: 8),
                            SizedBox(width: 40, child: Text('${(pct * 100).toStringAsFixed(0)}%', textAlign: TextAlign.right, style: const TextStyle(fontSize: 12, color: AppColors.textSecondary, fontWeight: FontWeight.w600))),
                          ],
                        ),
                        const SizedBox(height: 6),
                        ClipRRect(
                          borderRadius: BorderRadius.circular(4),
                          child: LinearProgressIndicator(
                            value: pct, minHeight: 7,
                            backgroundColor: AppColors.border,
                            valueColor: AlwaysStoppedAnimation(color),
                          ),
                        ),
                      ],
                    );
                  },
                ),
              ),
          ],
        ),
      ),
    );
  }

  // ── 4. Daily Budget sheet (Safe to Spend card) ────────────────────────────
  void _showDailyBudgetSheet(DailyStats stats, String Function(double) format) {
    final todaysExpenses = ref.read(todaysExpensesProvider);
    final isOverBudget = stats.remainingToday < 0;

    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (ctx) => Container(
        decoration: const BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.vertical(top: Radius.circular(32))),
        padding: const EdgeInsets.fromLTRB(24, 12, 24, 32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(child: Container(width: 40, height: 4, decoration: BoxDecoration(color: AppColors.border, borderRadius: BorderRadius.circular(2)))),
            const SizedBox(height: 20),
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(color: (isOverBudget ? AppColors.danger : const Color(0xFF6366F1)).withOpacity(0.12), borderRadius: BorderRadius.circular(14)),
                  child: Icon(Icons.flash_on_rounded, color: isOverBudget ? AppColors.danger : const Color(0xFF6366F1), size: 22),
                ),
                const SizedBox(width: 14),
                const Expanded(child: Text('Today\'s Budget', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800))),
              ],
            ),
            const SizedBox(height: 20),

            // 3-stat row
            Row(
              children: [
                Expanded(child: _StatChip(label: 'DAILY LIMIT', value: format(stats.dailyLimit), color: const Color(0xFF6366F1))),
                const SizedBox(width: 10),
                Expanded(child: _StatChip(label: 'SPENT', value: format(stats.spentToday), color: isOverBudget ? AppColors.danger : AppColors.textPrimary)),
                const SizedBox(width: 10),
                Expanded(child: _StatChip(label: 'REMAINING', value: format(stats.remainingToday < 0 ? 0 : stats.remainingToday), color: isOverBudget ? AppColors.danger : AppColors.success)),
              ],
            ),
            const SizedBox(height: 20),

            // Today's expenses list
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text("TODAY'S EXPENSES", style: TextStyle(fontSize: 11, fontWeight: FontWeight.w800, color: AppColors.textSecondary, letterSpacing: 1.2)),
                Text('${todaysExpenses.length} items', style: const TextStyle(fontSize: 12, color: AppColors.textSecondary)),
              ],
            ),
            const SizedBox(height: 12),

            if (todaysExpenses.isEmpty)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 20),
                child: Center(
                  child: Column(
                    children: [
                      Icon(Icons.receipt_long_outlined, size: 40, color: AppColors.textSecondary.withOpacity(0.3)),
                      const SizedBox(height: 8),
                      const Text('No expenses today', style: TextStyle(color: AppColors.textSecondary, fontWeight: FontWeight.w500)),
                    ],
                  ),
                ),
              )
            else
              ConstrainedBox(
                constraints: BoxConstraints(maxHeight: MediaQuery.of(ctx).size.height * 0.3),
                child: ListView.builder(
                  shrinkWrap: true,
                  itemCount: todaysExpenses.length,
                  itemBuilder: (_, i) {
                    final e = todaysExpenses[i];
                    final cat = e.category.isNotEmpty ? (e.category[0].toUpperCase() + e.category.substring(1).toLowerCase()) : 'Other';
                    return Container(
                      margin: const EdgeInsets.only(bottom: 8),
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                      decoration: BoxDecoration(color: AppColors.background, borderRadius: BorderRadius.circular(14), border: Border.all(color: AppColors.border)),
                      child: Row(
                        children: [
                          Container(padding: const EdgeInsets.all(8), decoration: BoxDecoration(color: AppColors.primary.withOpacity(0.1), borderRadius: BorderRadius.circular(10)), child: const Icon(Icons.receipt_rounded, color: AppColors.primary, size: 16)),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                              Text(cat, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13)),
                              if (e.note != null && e.note!.isNotEmpty)
                                Text(e.note!, style: const TextStyle(fontSize: 11, color: AppColors.textSecondary)),
                            ]),
                          ),
                          Text(format(e.amount), style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 14, color: AppColors.danger)),
                        ],
                      ),
                    );
                  },
                ),
              ),

            const SizedBox(height: 16),

            // Add Expense button
            SizedBox(
              width: double.infinity,
              height: 54,
              child: ElevatedButton.icon(
                onPressed: () {
                  Navigator.pop(ctx);
                  context.push('/add-expense');
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.primary, elevation: 0,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
                ),
                icon: const Icon(Icons.add_rounded, color: Colors.white),
                label: const Text('ADD EXPENSE', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, letterSpacing: 1)),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showFixedExpensesSheet(BuildContext context, String? breakdownJson, String Function(double) format) {
    final icons = <String, IconData>{'Rent/Mortgage': Icons.home_rounded, 'Utilities & Bills': Icons.bolt_rounded, 'Food & Groceries': Icons.shopping_basket_rounded, 'Transport/Fuel': Icons.directions_car_rounded, 'Other Fixed': Icons.more_horiz_rounded};

    showModalBottomSheet(
      context: context, backgroundColor: Colors.transparent, isScrollControlled: true,
      builder: (sheetContext) => StatefulBuilder(
        builder: (ctx, setSheetState) {
          final Map<String, double> items = ref.read(userSettingsProvider)?.expensesBreakdown != null
              ? Map<String, double>.from(jsonDecode(ref.read(userSettingsProvider)!.expensesBreakdown!) as Map)
              : (breakdownJson != null ? Map<String, double>.from(jsonDecode(breakdownJson) as Map) : {});

          Future<void> saveBreakdown(Map<String, double> updated) async {
            final s = ref.read(userSettingsProvider);
            if (s == null) return;
            final newTotal = updated.values.fold(0.0, (a, b) => a + b);
            final encoded = jsonEncode(updated);
            s.expensesBreakdown = encoded;
            s.fixedExpenses = newTotal;
            await s.save();
            ref.read(userSettingsProvider.notifier).state = s;
            FirestoreService.saveUserSetup(
              monthlyIncome: s.monthlyIncome,
              nextSalaryDate: s.nextSalaryDate,
              fixedExpenses: newTotal,
              savingsGoal: s.savingsGoal,
              currencyCode: s.currencyCode,
              expensesBreakdown: encoded,
            ).catchError((_) {});
            ref.invalidate(dailyStatsProvider);
            setSheetState(() {});
          }

          void editEntry(String key, double value) {
            final nameCtrl = TextEditingController(text: key);
            final amountCtrl = TextEditingController(text: value.toStringAsFixed(0));
            showDialog(
              context: ctx,
              builder: (dCtx) => AlertDialog(
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                title: const Text('Edit Fixed Expense', style: TextStyle(fontWeight: FontWeight.w800)),
                content: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    TextField(
                      controller: nameCtrl,
                      decoration: InputDecoration(
                        labelText: 'Name',
                        prefixIcon: const Icon(Icons.label_rounded),
                        border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
                      ),
                    ),
                    const SizedBox(height: 12),
                    TextField(
                      controller: amountCtrl,
                      keyboardType: TextInputType.number,
                      decoration: InputDecoration(
                        labelText: 'Amount',
                        prefixIcon: const Icon(Icons.payments_rounded),
                        border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
                      ),
                    ),
                  ],
                ),
                actions: [
                  TextButton(onPressed: () => Navigator.pop(dCtx), child: const Text('Cancel')),
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(backgroundColor: AppColors.primary, elevation: 0, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
                    onPressed: () async {
                      final newAmount = double.tryParse(amountCtrl.text.trim());
                      if (newAmount == null || newAmount < 0) return;
                      final newName = nameCtrl.text.trim();
                      if (newName.isEmpty) return;
                      final updated = Map<String, double>.from(items);
                      if (newName != key) updated.remove(key);
                      updated[newName] = newAmount;
                      Navigator.pop(dCtx);
                      await saveBreakdown(updated);
                    },
                    child: const Text('Save', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700)),
                  ),
                ],
              ),
            );
          }

          void deleteEntry(String key) async {
            final confirmed = await showDialog<bool>(
              context: ctx,
              builder: (dCtx) => AlertDialog(
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                title: const Text('Delete this expense?', style: TextStyle(fontWeight: FontWeight.w800)),
                content: Text('Remove "$key" from fixed expenses?'),
                actions: [
                  TextButton(onPressed: () => Navigator.pop(dCtx, false), child: const Text('Cancel')),
                  ElevatedButton(
                    onPressed: () => Navigator.pop(dCtx, true),
                    style: ElevatedButton.styleFrom(backgroundColor: AppColors.danger, elevation: 0, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
                    child: const Text('Delete', style: TextStyle(color: Colors.white)),
                  ),
                ],
              ),
            );
            if (confirmed != true) return;
            final updated = Map<String, double>.from(items)..remove(key);
            await saveBreakdown(updated);
          }

          return Container(
            decoration: const BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.vertical(top: Radius.circular(32))),
            padding: EdgeInsets.fromLTRB(24, 12, 24, MediaQuery.of(ctx).viewInsets.bottom + 32),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(width: 40, height: 4, decoration: BoxDecoration(color: AppColors.border, borderRadius: BorderRadius.circular(2))),
                const SizedBox(height: 24),
                const Text('Fixed Expenses', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: AppColors.textPrimary)),
                const SizedBox(height: 24),
                if (items.isEmpty)
                  const Padding(
                    padding: EdgeInsets.symmetric(vertical: 16),
                    child: Text('No fixed expenses.', style: TextStyle(color: AppColors.textSecondary)),
                  )
                else
                  ...items.entries.map((entry) {
                    final capturedKey = entry.key;
                    final capturedValue = entry.value;
                    return Container(
                      margin: const EdgeInsets.only(bottom: 12),
                      padding: const EdgeInsets.only(left: 18, top: 10, bottom: 10, right: 12),
                      decoration: BoxDecoration(color: AppColors.background, borderRadius: BorderRadius.circular(18), border: Border.all(color: AppColors.border)),
                      child: Row(
                        children: [
                          Container(padding: const EdgeInsets.all(10), decoration: BoxDecoration(color: AppColors.primary.withOpacity(0.1), borderRadius: BorderRadius.circular(12)), child: Icon(icons[capturedKey] ?? Icons.receipt_rounded, color: AppColors.primary, size: 20)),
                          const SizedBox(width: 14),
                          Expanded(child: Text(capturedKey, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14, color: AppColors.textPrimary))),
                          Text(format(capturedValue), style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15, color: Color(0xFF3B82F6))),
                          const SizedBox(width: 10),
                          GestureDetector(
                            onTapDown: (TapDownDetails d) async {
                              final RenderBox overlay = Overlay.of(ctx).context.findRenderObject()! as RenderBox;
                              final result = await showMenu<String>(
                                context: ctx,
                                position: RelativeRect.fromRect(
                                  d.globalPosition & const Size(1, 1),
                                  Offset.zero & overlay.size,
                                ),
                                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                                items: [
                                  PopupMenuItem(
                                    value: 'edit',
                                    child: Row(children: const [
                                      Icon(Icons.edit_rounded, size: 18, color: Color(0xFF3B82F6)),
                                      SizedBox(width: 10),
                                      Text('Edit', style: TextStyle(fontWeight: FontWeight.w600, color: Color(0xFF3B82F6))),
                                    ]),
                                  ),
                                  PopupMenuItem(
                                    value: 'delete',
                                    child: Row(children: const [
                                      Icon(Icons.delete_rounded, size: 18, color: AppColors.danger),
                                      SizedBox(width: 10),
                                      Text('Delete', style: TextStyle(fontWeight: FontWeight.w600, color: AppColors.danger)),
                                    ]),
                                  ),
                                ],
                              );
                              if (result == 'edit') editEntry(capturedKey, capturedValue);
                              if (result == 'delete') deleteEntry(capturedKey);
                            },
                            child: Container(
                              width: 34,
                              height: 34,
                              alignment: Alignment.center,
                              decoration: BoxDecoration(
                                color: AppColors.primary.withOpacity(0.12),
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: const Icon(Icons.more_vert_rounded, color: AppColors.primary, size: 20),
                            ),
                          ),
                        ],
                      ),
                    );
                  }),
                const Divider(color: AppColors.border, height: 32),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text('Total', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: AppColors.textPrimary)),
                    Text(format(items.values.fold(0.0, (a, b) => a + b)), style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: AppColors.primary)),
                  ],
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  // ── Payday Details Sheet ──────────────────────────────────────────────────
  void _showPaydayDetailsSheet(DailyStats initialStats, String Function(double) format) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (sheetCtx) => StatefulBuilder(
        builder: (ctx, setSheetState) {
          final stats = ref.read(dailyStatsProvider) ?? initialStats;
          final s = ref.read(userSettingsProvider);
          if (s == null) return const SizedBox();

          return DraggableScrollableSheet(
            initialChildSize: 0.88,
            minChildSize: 0.5,
            maxChildSize: 0.96,
            builder: (_, scrollController) => Container(
              decoration: const BoxDecoration(
                color: AppColors.background,
                borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
              ),
              child: Column(
                children: [
                  const SizedBox(height: 12),
                  Container(width: 40, height: 4, decoration: BoxDecoration(color: AppColors.border, borderRadius: BorderRadius.circular(2))),

                  // Gradient header
                  Container(
                    margin: const EdgeInsets.fromLTRB(20, 20, 20, 0),
                    padding: const EdgeInsets.all(22),
                    decoration: BoxDecoration(
                      gradient: AppColors.primaryGradient,
                      borderRadius: BorderRadius.circular(24),
                      boxShadow: [BoxShadow(color: AppColors.primary.withOpacity(0.3), blurRadius: 16, offset: const Offset(0, 6))],
                    ),
                    child: Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(color: Colors.white.withOpacity(0.2), borderRadius: BorderRadius.circular(16)),
                          child: const Icon(Icons.calendar_month_rounded, color: Colors.white, size: 26),
                        ),
                        const SizedBox(width: 16),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text('Payday Details', style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.w900, letterSpacing: -0.5)),
                              Text('${stats.daysLeft} day${stats.daysLeft != 1 ? 's' : ''} remaining', style: TextStyle(color: Colors.white.withOpacity(0.85), fontSize: 14, fontWeight: FontWeight.w500)),
                            ],
                          ),
                        ),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                          decoration: BoxDecoration(color: Colors.white.withOpacity(0.2), borderRadius: BorderRadius.circular(20)),
                          child: Text(DateFormat('d MMM').format(s.nextSalaryDate), style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 13)),
                        ),
                      ],
                    ),
                  ),

                  Expanded(
                    child: ListView(
                      controller: scrollController,
                      padding: const EdgeInsets.fromLTRB(20, 20, 20, 32),
                      children: [
                        // ── Payday info ──────────────────────────────
                        const _SheetSectionLabel(label: 'PAYDAY INFO'),
                        const SizedBox(height: 12),
                        _PaydayDetailRow(icon: Icons.event_rounded, iconColor: AppColors.primary, label: 'Next Payday Date', value: DateFormat('EEEE, d MMMM yyyy').format(s.nextSalaryDate)),
                        _PaydayDetailRow(icon: Icons.hourglass_bottom_rounded, iconColor: AppColors.warning, label: 'Days Remaining', value: '${stats.daysLeft} day${stats.daysLeft != 1 ? 's' : ''}'),
                        _PaydayDetailRow(icon: Icons.account_balance_rounded, iconColor: stats.remainingBalance >= 0 ? AppColors.success : AppColors.danger, label: 'Remaining Budget', value: format(stats.remainingBalance), valueColor: stats.remainingBalance >= 0 ? AppColors.success : AppColors.danger),
                        _PaydayDetailRow(icon: Icons.today_rounded, iconColor: AppColors.primary, label: 'Safe to Spend / Day', value: format(stats.dailyLimit), valueColor: AppColors.primary),

                        const SizedBox(height: 24),

                        // ── Monthly breakdown ────────────────────────
                        const _SheetSectionLabel(label: 'MONTHLY BREAKDOWN'),
                        const SizedBox(height: 12),
                        _PaydayDetailRow(icon: Icons.payments_rounded, iconColor: AppColors.success, label: 'Total Monthly Income', value: format(stats.monthlyIncome)),
                        _PaydayDetailRow(icon: Icons.receipt_long_rounded, iconColor: const Color(0xFF3B82F6), label: 'Fixed Expenses', value: format(stats.fixedExpenses)),
                        _PaydayDetailRow(icon: Icons.savings_rounded, iconColor: const Color(0xFF8B5CF6), label: 'Savings Goal', value: format(stats.savingsGoal)),

                        const SizedBox(height: 24),

                        // ── Budget calculation ───────────────────────
                        const _SheetSectionLabel(label: 'BUDGET SUMMARY'),
                        const SizedBox(height: 12),
                        Container(
                          padding: const EdgeInsets.all(20),
                          decoration: BoxDecoration(
                            color: AppColors.surface,
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(color: AppColors.border),
                          ),
                          child: Column(
                            children: [
                              _CalcRow(label: 'Monthly Income', value: format(stats.monthlyIncome)),
                              const SizedBox(height: 10),
                              _CalcRow(label: '− Fixed Expenses', value: format(stats.fixedExpenses), valueColor: AppColors.danger),
                              const SizedBox(height: 10),
                              _CalcRow(label: '− Savings Goal', value: format(stats.savingsGoal), valueColor: const Color(0xFF8B5CF6)),
                              const Padding(
                                padding: EdgeInsets.symmetric(vertical: 12),
                                child: Divider(height: 1, color: AppColors.border),
                              ),
                              _CalcRow(label: '= Available Budget', value: format(stats.availableSpending), valueColor: AppColors.success, bold: true),
                              const SizedBox(height: 16),
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                                decoration: BoxDecoration(
                                  gradient: LinearGradient(colors: [AppColors.primary.withOpacity(0.08), AppColors.secondary.withOpacity(0.06)]),
                                  borderRadius: BorderRadius.circular(14),
                                  border: Border.all(color: AppColors.primary.withOpacity(0.15)),
                                ),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Flexible(child: Text(format(stats.availableSpending), style: const TextStyle(fontWeight: FontWeight.w800, color: AppColors.primary, fontSize: 13), overflow: TextOverflow.ellipsis)),
                                    const Padding(
                                      padding: EdgeInsets.symmetric(horizontal: 6),
                                      child: Text('÷', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 15, color: AppColors.textSecondary)),
                                    ),
                                    Text('${stats.daysLeft}d', style: const TextStyle(fontWeight: FontWeight.w800, color: AppColors.primary, fontSize: 13)),
                                    const Padding(
                                      padding: EdgeInsets.symmetric(horizontal: 6),
                                      child: Text('=', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 15, color: AppColors.textSecondary)),
                                    ),
                                    Flexible(child: Text(format(stats.dailyLimit), style: const TextStyle(fontWeight: FontWeight.w900, color: AppColors.success, fontSize: 14), overflow: TextOverflow.ellipsis)),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),

                        const SizedBox(height: 28),

                        // ── Actions ──────────────────────────────────
                        SizedBox(
                          width: double.infinity,
                          height: 54,
                          child: ElevatedButton.icon(
                            onPressed: () async {
                              final picked = await showDatePicker(
                                context: ctx,
                                initialDate: s.nextSalaryDate.isAfter(DateTime.now()) ? s.nextSalaryDate : DateTime.now().add(const Duration(days: 1)),
                                firstDate: DateTime.now(),
                                lastDate: DateTime.now().add(const Duration(days: 365)),
                                builder: (context, child) => Theme(
                                  data: Theme.of(context).copyWith(
                                    colorScheme: const ColorScheme.light(primary: AppColors.primary, onPrimary: Colors.white),
                                  ),
                                  child: child!,
                                ),
                              );
                              if (picked == null || !ctx.mounted) return;
                              s.nextSalaryDate = picked;
                              await s.save();
                              ref.read(userSettingsProvider.notifier).state = s;
                              ref.invalidate(dailyStatsProvider);
                              FirestoreService.saveUserSetup(
                                monthlyIncome: s.monthlyIncome,
                                nextSalaryDate: picked,
                                fixedExpenses: s.fixedExpenses,
                                savingsGoal: s.savingsGoal,
                                currencyCode: s.currencyCode,
                                expensesBreakdown: s.expensesBreakdown,
                              ).catchError((_) {});
                              setSheetState(() {});
                            },
                            style: ElevatedButton.styleFrom(
                              backgroundColor: AppColors.primary, elevation: 0,
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                            ),
                            icon: const Icon(Icons.edit_calendar_rounded, color: Colors.white, size: 20),
                            label: const Text('EDIT PAYDAY DATE', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, letterSpacing: 1)),
                          ),
                        ),
                        const SizedBox(height: 12),
                        SizedBox(
                          width: double.infinity,
                          height: 50,
                          child: OutlinedButton(
                            onPressed: () => Navigator.pop(ctx),
                            style: OutlinedButton.styleFrom(
                              side: const BorderSide(color: AppColors.border, width: 1.5),
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                            ),
                            child: const Text('CLOSE', style: TextStyle(color: AppColors.textSecondary, fontWeight: FontWeight.w800, letterSpacing: 1)),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Color _getRemainingBalanceColor(double remaining, double income) {
    if (remaining <= 0) return AppColors.danger;
    final ratio = remaining / (income > 0 ? income : 1);
    if (ratio < 0.1) return AppColors.danger;
    if (ratio < 0.25) return AppColors.warning;
    return AppColors.success;
  }
}

// ── Swipeable Expense Item ────────────────────────────────────────────────────
class _SwipeableExpenseItem extends StatefulWidget {
  final Expense expense;
  final String Function(double) format;
  final VoidCallback onEdit;
  final VoidCallback onDelete;

  const _SwipeableExpenseItem({super.key, required this.expense, required this.format, required this.onEdit, required this.onDelete});

  @override
  State<_SwipeableExpenseItem> createState() => _SwipeableExpenseItemState();
}

class _SwipeableExpenseItemState extends State<_SwipeableExpenseItem> {
  double _offset = 0;
  static const double _revealWidth = 152.0; // 76 edit + 76 delete

  void _onDragUpdate(DragUpdateDetails d) {
    setState(() => _offset = (_offset + d.delta.dx).clamp(-_revealWidth, 0.0));
  }

  void _onDragEnd(DragEndDetails d) {
    final snap = _offset < -_revealWidth / 2 ? -_revealWidth : 0.0;
    setState(() => _offset = snap);
  }

  void _close() => setState(() => _offset = 0);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onHorizontalDragUpdate: _onDragUpdate,
      onHorizontalDragEnd: _onDragEnd,
      child: Container(
        height: 76,
        margin: const EdgeInsets.only(bottom: 12),
        child: Stack(
          clipBehavior: Clip.hardEdge,
          children: [
            // ── Action buttons behind the card ─────────────────────
            Positioned.fill(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  // EDIT
                  GestureDetector(
                    onTap: () { _close(); widget.onEdit(); },
                    child: Container(
                      width: 76,
                      decoration: const BoxDecoration(
                        color: Color(0xFF3B82F6),
                        borderRadius: BorderRadius.only(topLeft: Radius.circular(24), bottomLeft: Radius.circular(24)),
                      ),
                      child: const Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.edit_rounded, color: Colors.white, size: 22),
                          SizedBox(height: 4),
                          Text('EDIT', style: TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w800, letterSpacing: 0.5)),
                        ],
                      ),
                    ),
                  ),
                  // DELETE
                  GestureDetector(
                    onTap: () { _close(); widget.onDelete(); },
                    child: Container(
                      width: 76,
                      decoration: const BoxDecoration(
                        color: AppColors.danger,
                        borderRadius: BorderRadius.only(topRight: Radius.circular(24), bottomRight: Radius.circular(24)),
                      ),
                      child: const Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.delete_rounded, color: Colors.white, size: 22),
                          SizedBox(height: 4),
                          Text('DELETE', style: TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w800, letterSpacing: 0.5)),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),

            // ── Sliding card ───────────────────────────────────────
            AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              curve: Curves.easeOut,
              transform: Matrix4.translationValues(_offset, 0, 0),
              child: GestureDetector(
                onTap: _offset != 0 ? _close : null,
                child: Container(
                  height: 76,
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
                  decoration: BoxDecoration(
                    color: AppColors.surface,
                    borderRadius: BorderRadius.circular(24),
                    border: Border.all(color: AppColors.border),
                    boxShadow: [BoxShadow(color: AppColors.primary.withOpacity(0.06), blurRadius: 12, offset: const Offset(0, 4))],
                  ),
                  child: Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(color: AppColors.primary.withOpacity(0.1), borderRadius: BorderRadius.circular(14)),
                        child: const Icon(Icons.receipt_rounded, color: AppColors.primary, size: 22),
                      ),
                      const SizedBox(width: 14),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(widget.expense.category.toUpperCase(), style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 13, letterSpacing: 0.5)),
                            if (widget.expense.note != null && widget.expense.note!.isNotEmpty) ...[
                              const SizedBox(height: 3),
                              Text(widget.expense.note!, style: const TextStyle(fontSize: 12, color: AppColors.textSecondary)),
                            ],
                          ],
                        ),
                      ),
                      Text(widget.format(widget.expense.amount), style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 17, color: AppColors.danger, letterSpacing: -0.5)),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ── Stat Chip (used in Daily Budget sheet) ────────────────────────────────────
class _StatChip extends StatelessWidget {
  final String label;
  final String value;
  final Color color;
  const _StatChip({required this.label, required this.value, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 10),
      decoration: BoxDecoration(color: AppColors.background, borderRadius: BorderRadius.circular(14), border: Border.all(color: AppColors.border)),
      child: Column(
        children: [
          Text(label, style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w700, color: AppColors.textSecondary, letterSpacing: 0.8)),
          const SizedBox(height: 6),
          FittedBox(fit: BoxFit.scaleDown, child: Text(value, style: TextStyle(fontSize: 15, fontWeight: FontWeight.w900, color: color))),
        ],
      ),
    );
  }
}

// ── Payday Sheet Helpers ──────────────────────────────────────────────────────
class _SheetSectionLabel extends StatelessWidget {
  final String label;
  const _SheetSectionLabel({required this.label});

  @override
  Widget build(BuildContext context) {
    return Text(label, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w800, color: AppColors.textSecondary, letterSpacing: 1.4));
  }
}

class _PaydayDetailRow extends StatelessWidget {
  final IconData icon;
  final Color iconColor;
  final String label;
  final String value;
  final Color? valueColor;

  const _PaydayDetailRow({required this.icon, required this.iconColor, required this.label, required this.value, this.valueColor});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.border),
      ),
      child: Row(
        children: [
          Container(
            width: 36, height: 36,
            decoration: BoxDecoration(color: iconColor.withOpacity(0.1), borderRadius: BorderRadius.circular(10)),
            child: Icon(icon, color: iconColor, size: 18),
          ),
          const SizedBox(width: 14),
          Expanded(child: Text(label, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600, color: AppColors.textSecondary))),
          Flexible(child: Text(value, style: TextStyle(fontSize: 14, fontWeight: FontWeight.w800, color: valueColor ?? AppColors.textPrimary), textAlign: TextAlign.end)),
        ],
      ),
    );
  }
}

class _CalcRow extends StatelessWidget {
  final String label;
  final String value;
  final Color? valueColor;
  final bool bold;

  const _CalcRow({required this.label, required this.value, this.valueColor, this.bold = false});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(label, style: TextStyle(fontSize: 14, fontWeight: bold ? FontWeight.w800 : FontWeight.w500, color: bold ? AppColors.textPrimary : AppColors.textSecondary)),
        Text(value, style: TextStyle(fontSize: 14, fontWeight: bold ? FontWeight.w900 : FontWeight.w700, color: valueColor ?? (bold ? AppColors.success : AppColors.textPrimary))),
      ],
    );
  }
}

// ── Summary Card ──────────────────────────────────────────────────────────────
class _SummaryCard extends StatelessWidget {
  final String label;
  final String formattedValue;
  final IconData icon;
  final Color color;
  final Color iconTint;
  final bool isHighlighted;
  final VoidCallback? onTap;

  const _SummaryCard({required this.label, required this.formattedValue, required this.icon, required this.color, required this.iconTint, this.isHighlighted = false, this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: isHighlighted ? color.withOpacity(0.5) : AppColors.border, width: isHighlighted ? 2 : 1.5),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Container(padding: const EdgeInsets.all(8), decoration: BoxDecoration(color: iconTint.withOpacity(0.15), borderRadius: BorderRadius.circular(12)), child: Icon(icon, color: iconTint, size: 22)),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(label, style: const TextStyle(fontSize: 11, color: AppColors.textSecondary, fontWeight: FontWeight.w600, letterSpacing: 0.5)),
                const SizedBox(height: 4),
                FittedBox(fit: BoxFit.scaleDown, child: Text(formattedValue, style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: isHighlighted ? color : AppColors.textPrimary, letterSpacing: -0.5))),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
