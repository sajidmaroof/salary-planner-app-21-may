import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class FirestoreService {
  static final _db = FirebaseFirestore.instance;

  static Future<void> saveUserSetup({
    required double monthlyIncome,
    required DateTime nextSalaryDate,
    required double fixedExpenses,
    required double savingsGoal,
    required String currencyCode,
    String? expensesBreakdown,
  }) async {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid == null) return;
    await _db.collection('users').doc(uid).set({
      'monthlyIncome': monthlyIncome,
      'nextSalaryDate': Timestamp.fromDate(nextSalaryDate),
      'fixedExpenses': fixedExpenses,
      'savingsGoal': savingsGoal,
      'currencyCode': currencyCode,
      'expensesBreakdown': expensesBreakdown,
      'setupComplete': true,
      'updatedAt': FieldValue.serverTimestamp(),
    }, SetOptions(merge: true));
  }

  static Future<Map<String, dynamic>?> getUserData() async {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid == null) return null;
    final doc = await _db.collection('users').doc(uid).get();
    return doc.data();
  }

  static Future<void> clearUserData() async {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid == null) return;
    await _db.collection('users').doc(uid).delete();
  }
}
